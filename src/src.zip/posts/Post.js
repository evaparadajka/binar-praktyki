import React from "react"; 

class Post extends React.Component 
{  
constructor(props){
super(props);
this.id = this.props.timestamp;
}

usun = () =>{

}


render() {    
return (
<div>
title: {this.props.title} <br/>
timestamp: {this.props.timestamp}<br/><br/>
id: {this.id}<br/><br/>
<button onClick={this.usun}>USUN</button>
</div>    
);  
} 
} 


export default Post;
