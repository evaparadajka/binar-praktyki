import React, { Component } from "react"; 
//import logo from "./logo.svg";
//import PropTypes from "prop-types"; 
// import "./App.css"; 

import PostForm from "./posts/PostForm.js";
import PostList from "./posts/PostList.js";




class App extends Component{ 

 constructor(props){    
super(props);   
 
this.state = {
posts: [],    
}; 
   
 
} 

addPost = post => {   
	this.setState({
		posts:  [...this.state.posts, {...post,timestamp:new Date().getTime()}],

	});
 

}  


render() {    
return (      
<div className="App">        
<PostForm onSubmit={this.addPost}/>
    
<PostList posts={this.state.posts}/>
</div>    
);  
} } 




export default App;
